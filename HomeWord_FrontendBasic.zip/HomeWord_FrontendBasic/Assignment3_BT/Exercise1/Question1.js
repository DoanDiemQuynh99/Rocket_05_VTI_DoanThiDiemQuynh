function Department(DepartmentID, DepartmentName){
    this.DepartmentID= DepartmentID;
    this.DepartmentName= DepartmentName;
}
var Dep1= new Department(1, "sale");
var Dep2= new Department(2,"marketing");
var Dep3= new Department(3,"lap trinh");

function Position(PositonID,PositionName) {
    this.PositonID= PositonID;
    this.PositionName= PositionName;
};
 var Pos1= new Position(1,"Dev");
 var Pos2= new Position(2,"Test");
 var Pos3= new Position(3,"Scrum Master");
 var Pos4= new Position(4,"PM");

 function Account(AccountID, Email, Username, FullName, DepartmentID, PositionID, CreateDate) {
    this.AccountID= AccountID;
    this.Email= Email;
    this.Username= Username;
    this.FullName= FullName;
    this.DepartmentID= DepartmentID;
    this.PositionID= PositionID;
    this.CreateDate= CreateDate;
 };
var Acc1= new Account(1,"quynhodan13849@gmail.com","Doan Quynh","Doan Thi Diem Quynh",3,1,12/10/2019);

function Group(GroupID, GroupName, CreatorID, CreateDate){
 this.GroupID= GroupID;
 this.GroupName= GroupName;
 this.CreatorID= CreatorID;
 this.CreateDate= CreateDate;
};

function GroupAccount(GroupID, AccountID, JoinDate){
this.GroupID= GroupID;
this.AccountID= AccountID;
this.JoinDate= JoinDate;
};
var GA1 = new GroupAccount(1,1,"");
console.log(Dep1.DepartmentName);


