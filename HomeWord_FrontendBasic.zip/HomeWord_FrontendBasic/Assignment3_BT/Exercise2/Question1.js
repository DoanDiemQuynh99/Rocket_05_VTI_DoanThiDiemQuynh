
    function Account(AccountID, Email, Username, FullName, DepartmentID, PositionID, CreateDate) {
        this.AccountID= AccountID;
        this.Email= Email;
        this.Username= Username;
        this.FullName= FullName;
        this.DepartmentID= DepartmentID;
        this.PositionID= PositionID;
        this.CreateDate= CreateDate;
     };
var Acc1= new Account(1,"quynhodan13849@gmail.com","Doan Quynh","Doan Thi Diem Quynh",3,1,12/10/2019);
    
//question1
if(Acc1.DepartmentID==null){
    console.log("nhan vien nay chua co phong ban");
}else{
    console.log("phong ban nhan vien nay la"+Acc1.DepartmentID);
}
//question2
function GroupAccount(GroupID, AccountID, JoinDate){
    this.GroupID= GroupID;
    this.AccountID= AccountID;
    this.JoinDate= JoinDate;
    };
    var GA1 = new GroupAccount(1,1,"");
if(GA1.GroupID== null){
    console.log("nhan vien nay chua co group");
}else{
    console.log("group cua nhan vien nay laf java fresher, c#fresher");
}

//question3:su dung toan tu 3 ngoi de lam question1
var salary = (Acc1.DepartmentID==null) ? "nhan vien chua co phong ban" : Acc1.DepartmentID;
console.log(salary) 
//question4:
var salary2 =(Acc1.PositionID==1)?"day la dev": "day k phai dev";
console.log(salary2)