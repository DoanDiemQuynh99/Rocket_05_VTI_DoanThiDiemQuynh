import java.time.LocalDate;
public class groupAccount {
int groupID, accountID;
LocalDate joinDate;
}
