import java.time.LocalDate;
public class Department {
int departmentID;
String departmentName;

}
