
public class Position {
int positionID;
String positionName;
}
