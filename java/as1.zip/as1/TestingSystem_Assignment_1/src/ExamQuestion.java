
public class ExamQuestion {
int examID, questionID;
}
