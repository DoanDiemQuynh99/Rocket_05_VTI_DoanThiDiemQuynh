import java.time.LocalDate;
public class Account {
int accountID,departmentID, positionID;
String email, userName, fullName;
LocalDate createDate;
}
