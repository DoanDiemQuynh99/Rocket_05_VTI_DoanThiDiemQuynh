
public class Program {

	public static void main(String[] args) {
		// create department
		Department dep1= new Department();
		dep1.departmentID=1;
		dep1.departmentName="marketing";
	
		// create Position
		Position pos1=new Position();
		pos1.positionID=1;
		pos1.positionName="";
			
		// create Account 
		Account acc1=new Account();
		acc1.accountID=1;
		acc1.departmentID=1;
		acc1.positionID=1;
		acc1.email ="quynhdoan1999@gmail.com";
		acc1.fullName="Doan Thi Diem Quynh";
		//acc1.createDate= new Date("2020/7/7");
	
				
		// create Group
		Group group1= new Group();
		group1.groupID=1;
		group1.groupName="C# Fresher";
		
		Group group2 = new Group();
		group2.groupID =2;
		group2.groupName ="Java Fresher";
				
		// create groupAccount 
		groupAccount ga1= new groupAccount();
		ga1.accountID= 1;
		ga1.groupID=1;
		
		groupAccount ga2 = new groupAccount();
		ga2.accountID= 2;
		ga2.groupID=2;
		
		// create typeQuestion
		typeQuestion tq1= new typeQuestion();
		tq1.typeID=1;
		tq1.typeName ="essay";
		
		typeQuestion tq2= new typeQuestion();
		tq1.typeID=2;
		tq1.typeName ="multiple choice";
		
		
		// create categoryQuestion
		categoryQuestion cq = new categoryQuestion();
		cq.categoryID=1;
		cq.categoryName="java";
		
		// create Question
		Question ques1=  new Question();
		ques1.questionID = 1;
		ques1.content ="Noi dung cau hoi 1";
		ques1.categoryID= 1;
		ques1.typeID =1;
		ques1.creatorID= 2;
		
				
		// create Answer 
		Answer ans1= new Answer();
		ans1.answerID=1;
		ans1.content ="Noi dung cau tra loi1";
		ans1.questionID=1;
		ans1.isCorrect=true;
		
		
		
		// create Exam
		Exam ex1 = new Exam();
		ex1.examID=1;
		ex1.categoryID= 2;
		ex1.title= " tieu de1";
		ex1.duration= 90;
		ex1.creatorID=3;
		ex1.code= 5;
		
		
		//create ExamQuestion
		ExamQuestion eq1= new ExamQuestion();
		eq1.examID=1;
		eq1.questionID=1;
		
		
		
		System.out.println ("Thong tin phong ban 1");
		System.out.println("name:"+dep1.departmentName);
		System.out.println("id:"+dep1.departmentID);
		System.out.println("\n");
	}

}
