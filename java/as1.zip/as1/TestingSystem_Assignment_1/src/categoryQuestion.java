
public class categoryQuestion {
int categoryID;
String categoryName;
}
