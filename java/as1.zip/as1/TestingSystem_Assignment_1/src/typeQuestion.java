
public class typeQuestion {
int typeID;
String typeName;
}
