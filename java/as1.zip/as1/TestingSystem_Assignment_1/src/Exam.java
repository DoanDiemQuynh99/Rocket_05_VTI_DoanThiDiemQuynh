import java.time.LocalDate;
public class Exam {
int examID, code, categoryID, duration, creatorID;
String title;
LocalDate createDate;
}
