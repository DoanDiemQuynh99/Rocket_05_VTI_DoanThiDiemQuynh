package UpdateAss4;

public class Test {

	public static void main(String[] args) {
		Abstraction abs = new Abstraction();
		abs.question1();
	

	}

}
