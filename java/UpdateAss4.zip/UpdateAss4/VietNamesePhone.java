package UpdateAss4;

public class VietNamesePhone extends Phone {

	@Override
	public
	void insertContact(String name, String number) {
			System.out.println("insert new contact"+name+number);	
	}

	@Override
	void removeContact(String name) {
		System.out.println("xoa"+name);
		
	}

	@Override
	public
	void updateContact(String name, String newPhone) {
		System.out.println("update"+name+newPhone);
		
	}

	@Override
	public
	void searchContact(String name) {
		System.out.println("tim kiem"+name);
		
	}

	@Override
	public void removeContact(String name, String string) {
		
		
	}

}
