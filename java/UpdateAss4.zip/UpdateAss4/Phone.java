package UpdateAss4;

import java.util.ArrayList;

public abstract class Phone {
	String name;
	String number;
	ArrayList<String> contact = new ArrayList<String>();
	
public	abstract void insertContact (String name, String number);
public	abstract void removeContact(String name, String string);
public	abstract void updateContact(String name, String newPhone);
public	abstract void searchContact(String name);
public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public ArrayList<String> getContact() {
		return contact;
	}
	public void setContact(ArrayList<String> contact) {
		this.contact = contact;
	}
	abstract void removeContact(String string);
	
	
	
}
