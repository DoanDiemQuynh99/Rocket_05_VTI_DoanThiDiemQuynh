package UpdateAss4;

public class Abstraction {
public void question1() {
	Phone phone = new VietNamesePhone();
	phone.removeContact("Diem Quynh");
	phone.insertContact("DiemQuynh", "01234345");
	phone.updateContact("ducDuy", "012334");
	phone.searchContact("DiemQuynh");
}


}
