package backend;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MainClass_Ex1 {
	static Scanner scanner = new Scanner(System.in);

	private static void inputAge() {
		int n = 0;
		String s1;
		System.out.println("nhap vao mot so");
		s1 = scanner.nextLine();
		
		if (n < 0) {
			throw new ArithmeticException("wrong input");
		}

	}

	public static void main(String[] args) {

		inputAge();
		int n ;
		String s1  ;

		s1 = scanner.nextLine();
			try {
				
				n = Integer.parseInt(s1);
				System.out.println("so ban nhap la " + n);

			} catch (Exception ex) {
				System.out.println( "wrong input an age int , input again");
				System.out.println("nhap lai");

			}

		
	}

}
