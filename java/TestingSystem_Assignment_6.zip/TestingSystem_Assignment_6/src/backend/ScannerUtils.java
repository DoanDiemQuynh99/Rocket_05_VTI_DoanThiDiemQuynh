package backend;

import java.util.Scanner;

public class ScannerUtils {

	private static int inputInt(String... errorMessage) {
		Scanner Scanner2 = new Scanner(System.in);
		while (true) {
			try {
				Integer.parseInt(Scanner2.nextLine());
			} catch (Exception e) {
				System.out.println(errorMessage);
				;
			}
		}

	}

	public static void main(String[] args) {
		inputInt();
		System.out.println("Nhập id: ");
		

	}

}
