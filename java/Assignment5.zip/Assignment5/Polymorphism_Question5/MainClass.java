package Polymorphism_Question5;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
