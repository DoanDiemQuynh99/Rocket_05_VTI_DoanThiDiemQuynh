package Polymorphism_Question5;

public abstract class DienThoaiDiDong implements TanCong {
	public void Nghe() {
		System.out.println("dang nghe");
	}
	public void Goi() {
		System.out.println("dang goi");
	}
	public void GuiTinNhan() {
		System.out.println("dang gui tin nhan");
	}
	public void NhanTin() {
		System.out.println("dang nhan tin");
	}
}

