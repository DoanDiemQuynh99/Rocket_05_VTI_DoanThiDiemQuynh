package Polymorphism_Question5;

public class DienThoaiThongMinh extends DienThoaiDiDong {
	private void SuDung3G() {
		System.out.println("su dung 3g");
	}

	private void ChupHinh() {
		System.out.println("dang chup hinh");
	}

	@Override
	public void tancong() {
		System.out.println(".....");
	}
	
}
