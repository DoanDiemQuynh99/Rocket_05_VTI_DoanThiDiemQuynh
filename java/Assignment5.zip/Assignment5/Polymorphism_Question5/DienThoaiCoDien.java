package Polymorphism_Question5;

public class DienThoaiCoDien extends DienThoaiDiDong{
private void NgheRadio() {
	System.out.println("nghe radio");
}
@Override
public void tancong() {
	System.out.println("...");
}
}
