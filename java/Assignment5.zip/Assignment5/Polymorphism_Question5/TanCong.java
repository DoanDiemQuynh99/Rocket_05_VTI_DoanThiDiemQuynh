package Polymorphism_Question5;

public interface TanCong {
void tancong();
}
