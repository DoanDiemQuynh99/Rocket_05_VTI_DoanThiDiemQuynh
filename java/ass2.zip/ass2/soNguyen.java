package Ass2;

public class soNguyen {
	static int a;
	static void inrasonguyen() {
		for (int i=0;i<10; i++) {
			System.out.println("in ra cac so nguyen chan nho hon 10 la: "+i);
			i++;
		}
	}
	
	static void inranguyenduong() {
		for (int i=1; i<10;i++) {
			System.out.println("in ra so nguyen duong nho hon 10 la :"+i);
		}
	}
}
