package Ass2;

public class exersise6 {
  
	public static void main(String[] args) {
		
//Question 1: Tạo method để in ra các số chẵn nguyên dương nhỏ hơn 10
		
		soNguyen.inrasonguyen();
		
//Question 2: Tạo method để in thông tin các account
	
		// create Account 
		Account acc1=new Account();
		acc1.accountID=1;
		acc1.departmentID=1;
		
		acc1.groups= null;
		acc1.positionID=1;
		acc1.email ="quynhdoan1999@gmail.com";
		acc1.fullName="Doan Thi Diem Quynh";
		
		Account acc2=new Account();
		acc2.accountID=2;
		acc2.departmentID=1;
		acc2.departmentID=1;

		acc2.positionID=1;
		acc2.email ="quyndoan1999@gmail.com";
		acc2.fullName="Doan Diem Quynh";
		
		
		
		Account acc3=new Account();
		acc3.departmentID=1;
		acc3.accountID=3;
		acc3.departmentID=2;
		acc3.positionID=1;
		acc3.email ="quynnh1999@gmail.com";
		acc3.fullName="Doan Diem Phuong";
		
		Account.inthongtinaccount();
		
				
//Question 3: Tạo method để in ra các số nguyên dương nhỏ hơn 10
		soNguyen.inranguyenduong();
		
		
		
	
	}

}
