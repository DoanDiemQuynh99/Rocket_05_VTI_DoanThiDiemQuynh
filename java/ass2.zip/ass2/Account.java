package Ass2;
import java.time.LocalDate;

public class Account {
	static int accountID, departmentID, positionID;
	static String email, userName, fullName;
	static LocalDate createDate;
	 static Group[] groups;
	 
			
	 static void inthongtinaccount() {
		 Account acc1=new Account();
			acc1.accountID=1;
			acc1.departmentID=1;
			
			acc1.groups= null;
			acc1.positionID=1;
			acc1.email ="quynhdoan1999@gmail.com";
			acc1.fullName="Doan Thi Diem Quynh";
			
			Account acc2=new Account();
			acc2.accountID=2;
			acc2.departmentID=1;
			acc2.departmentID=1;

			acc2.positionID=1;
			acc2.email ="quyndoan1999@gmail.com";
			acc2.fullName="Doan Diem Quynh";
			
			
			
			Account acc3=new Account();
			acc3.departmentID=1;
			acc3.accountID=3;
			acc3.departmentID=2;
			acc3.positionID=1;
			acc3.email ="quynnh1999@gmail.com";
			acc3.fullName="Doan Diem Phuong";
		 
		 Account[] accounts = { acc1, acc2, acc3 };
			for (Account account : accounts) {							
			System.out.println("Email: " + account.email);							
			System.out.println("FullName: " + account.fullName);							
			System.out.println("ID Department: " + account.departmentID);
					}
	 }
}
