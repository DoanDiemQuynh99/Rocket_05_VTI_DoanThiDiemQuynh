package Ass2;

public class categoryQuestion {
	int categoryID;
	String categoryName;
}
