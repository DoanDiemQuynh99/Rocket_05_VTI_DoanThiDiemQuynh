package Ass2;

public class dateInput {

}
