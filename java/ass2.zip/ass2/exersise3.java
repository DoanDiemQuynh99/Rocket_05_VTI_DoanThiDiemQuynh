package Ass2;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;
public class exersise3 {

	public static void main(String[] args) {
		// create department
				Department dep1= new Department();
				dep1.departmentID=1;
				dep1.departmentName="marketing";
				
				Department dep2= new Department();
				dep1.departmentID=2;
				dep1.departmentName="sale";
				
				
				Department dep3= new Department();
				dep1.departmentID=3;
				dep1.departmentName="lap trinh";
				
			
				// create Position
				Position pos1=new Position();
				pos1.positionID=1;
				pos1.positionName="";
					
				// create Account 
				Account acc1=new Account();
				acc1.accountID=1;
				acc1.departmentID=1;
				
				acc1.groups= null;
				acc1.positionID=1;
				acc1.email ="quynhdoan1999@gmail.com";
				acc1.fullName="Doan Thi Diem Quynh";
				
				Account acc2=new Account();
				acc2.accountID=2;
				acc2.departmentID=1;
				acc2.departmentID=1;

				acc2.positionID=1;
				acc2.email ="quyndoan1999@gmail.com";
				acc2.fullName="Doan Diem Quynh";
				
				
				
				Account acc3=new Account();
				acc3.departmentID=1;
				acc3.accountID=3;
				acc3.departmentID=2;
				acc3.positionID=1;
				acc3.email ="quynnh1999@gmail.com";
				acc3.fullName="Doan Diem Phuong";
			
				//acc1.createDate= new Date("2020/7/7");
			
				

						

				// create Group
				Group group1= new Group();
				group1.groupID=1;
				group1.groupName="C# Fresher";
				
				Group group2 = new Group();
				group2.groupID =2;
				group2.groupName ="Java Fresher";
				
				Group group3 = new Group();
				group3.groupID =3;
				group3.groupName ="SQL server";
				
						
				// create groupAccount 
				groupAccount ga1= new groupAccount();
				ga1.accountID= 1;
				ga1.groupID=1;
				
				groupAccount ga2 = new groupAccount();
				ga2.accountID= 2;
				ga2.groupID=2;
				
				// create typeQuestion
				typeQuestion tq1= new typeQuestion();
				tq1.typeID=1;
				tq1.typeName ="essay";
				
				typeQuestion tq2= new typeQuestion();
				tq1.typeID=2;
				tq1.typeName ="multiple choice";
				
				
				// create categoryQuestion
				categoryQuestion cq = new categoryQuestion();
				cq.categoryID=1;
				cq.categoryName="java";
				
				// create Question
				Question ques1=  new Question();
				ques1.questionID = 1;
				ques1.content ="Noi dung cau hoi 1";
				ques1.categoryID= 1;
				ques1.typeID =1;
				ques1.creatorID= 2;
				
						
				// create Answer 
				Answer ans1= new Answer();
				ans1.answerID=1;
				ans1.content ="Noi dung cau tra loi1";
				ans1.questionID=1;
				ans1.isCorrect=true;
				
				
				
				// create Exam
				Exam ex1 = new Exam();
				ex1.examID=1;
				ex1.categoryID= 2;
				ex1.title= " tieu de1";
				ex1.duration= 90;
				ex1.creatorID=3;
				ex1.code= 5;
				ex1.createDate= LocalDate.of(2020, 05, 05);
			
				
				Exam ex2 = new Exam();
				ex2.examID=2;
				ex2.categoryID= 2;
				ex2.title= " tieu de2";
				ex2.duration= 90;
				ex2.creatorID=3;
				ex2.code= 6;
				ex2.createDate= LocalDate.of(2020, 05, 05);
				
				//create ExamQuestion
				ExamQuestion eq1= new ExamQuestion();
				eq1.examID=1;
				eq1.questionID=1;		
				
				
		       // add account to group
				
				Account[] accountOfGroups1 = {acc1,acc2,acc3 };
				group1.accounts = accountOfGroups1;
				
				// add group to account
				Group[] groupOfAccount1 = { group1 };
				acc1.groups = groupOfAccount1;
				Group[] groupOfAccount2 = { group3 };
				acc2.groups = groupOfAccount2;
				Group[] groupOfAccount3 = { group1 };
				acc3.groups = groupOfAccount3;
				
/* question 1: In ra thông tin Exam thứ 1 và property create date sẽ được format
				theo định dạng vietnamese*/
		
//				Locale locale = new Locale("vi", "VN");
//				DateFormat dateformat = DateFormat.getDateInstance(DateFormat.DEFAULT,locale);
//				String date = dateformat.format(acc1.createDate);
//				System.out.println(ex1.title + ": " + date);

/*Question 2: In ra thông tin: Exam đã tạo ngày nào theo định dạng
Năm – tháng – ngày – giờ – phút – giây*/				
//				String pattern = "yyyy-MM-dd-HH-mm-ss";
//				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
//
//				Exam[] exams = { ex1, ex2 };
//				for (Exam exam : exams) {
//					date = simpleDateFormat.format(exam.createDate);
//					System.out.println(exam.code + date);
//				}

/*Question 3: Chỉ in ra năm của create date property trong Question 2*/
//				pattern = "yyyy";
//				simpleDateFormat = new SimpleDateFormat(pattern);
//				for (Exam exam : exams) {
//					date = simpleDateFormat.format(exam.createDate);
//					System.out.println(exam.code  + date);
//				}

//Question4:
//				pattern = "yyyy-MM";
//				simpleDateFormat = new SimpleDateFormat(pattern);
//				for (Exam exam : exams) {
//					date = simpleDateFormat.format(exam.createDate);
//					System.out.println(exam.code + ": " + date);
//				}
//
//				// Q6.
//				pattern = "MM-dd";
//				simpleDateFormat = new SimpleDateFormat(pattern);
//				for (Exam exam : exams) {
//					date = simpleDateFormat.format(exam.createDate);
//					System.out.println(exam.code + ": " + date);
//				}
//				
//				
				
				
				
			}
													
														

	}


