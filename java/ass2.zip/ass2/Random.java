package Ass2;
import java.util.Random;

public class Random {
	Random random

}
