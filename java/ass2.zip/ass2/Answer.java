package Ass2;

public class Answer {
	int answerID, questionID;
	String content;
	Boolean isCorrect;
}
