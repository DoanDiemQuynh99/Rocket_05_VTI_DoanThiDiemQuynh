package Ass2;

public class Scanner {
	
}
