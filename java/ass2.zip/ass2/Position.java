package Ass2;

public class Position {
	int positionID;
	String positionName;
}
