package Ass2;

public class ExamQuestion {
	int examID, questionID;
}
