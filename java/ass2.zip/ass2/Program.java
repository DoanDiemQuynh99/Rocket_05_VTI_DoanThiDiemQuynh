package Ass2;
import java.text.SimpleDateFormat;

public class Program {

	
	public static void main(String[] args) {	 
		// create department
				Department dep1= new Department();
				dep1.departmentID=1;
				dep1.departmentName="marketing";
				
				Department dep2= new Department();
				dep1.departmentID=2;
				dep1.departmentName="sale";
				
				
				Department dep3= new Department();
				dep1.departmentID=3;
				dep1.departmentName="lap trinh";
				
			
				// create Position
				Position pos1=new Position();
				pos1.positionID=1;
				pos1.positionName="";
					
				// create Account 
				Account acc1=new Account();
				acc1.accountID=1;
				acc1.departmentID=1;
				
				acc1.groups= null;
				acc1.positionID=1;
				acc1.email ="quynhdoan1999@gmail.com";
				acc1.fullName="Doan Thi Diem Quynh";
				
				Account acc2=new Account();
				acc2.accountID=2;
				acc2.departmentID=1;
				acc2.departmentID=1;
		
				acc2.positionID=1;
				acc2.email ="quyndoan1999@gmail.com";
				acc2.fullName="Doan Diem Quynh";
				
				
				
				Account acc3=new Account();
				acc3.departmentID=1;
				acc3.accountID=3;
				acc3.departmentID=2;
				acc3.positionID=1;
				acc3.email ="quynnh1999@gmail.com";
				acc3.fullName="Doan Diem Phuong";
			
				//acc1.createDate= new Date("2020/7/7");
			
				

						
		
				// create Group
				Group group1= new Group();
				group1.groupID=1;
				group1.groupName="C# Fresher";
				
				Group group2 = new Group();
				group2.groupID =2;
				group2.groupName ="Java Fresher";
				
				Group group3 = new Group();
				group3.groupID =3;
				group3.groupName ="SQL server";
				
						
				// create groupAccount 
				groupAccount ga1= new groupAccount();
				ga1.accountID= 1;
				ga1.groupID=1;
				
				groupAccount ga2 = new groupAccount();
				ga2.accountID= 2;
				ga2.groupID=2;
				
				// create typeQuestion
				typeQuestion tq1= new typeQuestion();
				tq1.typeID=1;
				tq1.typeName ="essay";
				
				typeQuestion tq2= new typeQuestion();
				tq1.typeID=2;
				tq1.typeName ="multiple choice";
				
				
				// create categoryQuestion
				categoryQuestion cq = new categoryQuestion();
				cq.categoryID=1;
				cq.categoryName="java";
				
				// create Question
				Question ques1=  new Question();
				ques1.questionID = 1;
				ques1.content ="Noi dung cau hoi 1";
				ques1.categoryID= 1;
				ques1.typeID =1;
				ques1.creatorID= 2;
				
						
				// create Answer 
				Answer ans1= new Answer();
				ans1.answerID=1;
				ans1.content ="Noi dung cau tra loi1";
				ans1.questionID=1;
				ans1.isCorrect=true;
				
				
				
				// create Exam
				Exam ex1 = new Exam();
				ex1.examID=1;
				ex1.categoryID= 2;
				ex1.title= " tieu de1";
				ex1.duration= 90;
				ex1.creatorID=3;
				ex1.code= 5;
				
				
				//create ExamQuestion
				ExamQuestion eq1= new ExamQuestion();
				eq1.examID=1;
				eq1.questionID=1;		
				
				
               // add account to group
				
				Account[] accountOfGroups1 = {acc1,acc2,acc3 };
				group1.accounts = accountOfGroups1;
				
				// add group to account
				Group[] groupOfAccount1 = { group1 };
				
				acc1.groups = groupOfAccount1;

						
				Group[] groupOfAccount2 = { group3 };
						
				acc2.groups = groupOfAccount2;

						
				Group[] groupOfAccount3 = { group1 };
						
				acc3.groups = groupOfAccount3;

					
			

									
//				// question 1
//				if (acc1.departmentID == 0) {
//					System.out.println("Nhan vien nay chua co phong ban");
//				}
//					else {
//						System.out.println("phong ban cua nhan vien nay la "+ acc1.departmentID);
//
//					}
//				
//				//question 2
//				if (acc2.groups == null) {
//					System.out.println("Nhân viên này chưa có group");
//				}else if (acc2.groups.length==1){
//					System.out.println("group cua nhan vien nay la:"+ acc2.groups.length);
//					}
//				else if (acc2.groups.length==2) {
//					System.out.println("group cua nhan vien nay la:"+ acc2.groups.length);
//				}
//				else if (acc2.groups.length==3) {
//					System.out.println("acc nay tham gia nhieu group");
//				}
//				else 
//					System.out.println("hong chuyen ");
				
				//question 5
				// lay ra sl acc trong nhom nhat:
//				int x = group1.accounts.length;
//				switch (x) {
//				case 1: 
//					System.out.println("nhom co 1 thanh vien");
//					break;
//				case 2:
//					System.out.println("nhom co 2 thanh vien");
//					break;
//				case 3:
//					System.out.println("nhom co 3 thanh vien");
//				default : 
//					System.out.println("nhom co nhieu thanh vien nhat");
//					
//				}
				//question 6:Sử dụng switch case để làm lại Question 2
//			
//				 int y = acc2.groups.length;
//				 switch (y) {
//				 case 0: 
//					 System.out.println("nhan vien nay chua co group");
//					 break;
//				 case 1:
//					 System.out.println("Nhan vien nay co group"+ acc2.groups[0]);
//					 break;
//				 case 2:
//					 System.out.println("nhan vien nay co group"+acc2.groups[0]+acc2.groups[1]);
//					 break;
//				 case 3:
//					 System.out.println("nhan vien nay người quan trọng, tham gia nhiều group");
//					 break;
//				 default:
//					 System.out.println("Nhân viên này là người hóng chuyện, tham gia tất cả các group"); 
//					 		
//				 }
			
// question 8:	in ra thông tin các account bao gồm: Email, FullName và tên phòng ban của họ (for each)
//				Account[] accounts = { acc1, acc2, acc3 };
//				for (Account account : accounts) {							
//				System.out.println("Email: " + account.email);							
//				System.out.println("FullName: " + account.fullName);							
//				System.out.println("ID Department: " + account.departmentID);
//						}
//				
// question 9 (for each)
//				Department[] departments = {dep1, dep2, dep3};
//				for (Department department: departments) {
//					System.out.println("id"+department.departmentID);
//					System.out.println("name"+department.departmentName);
//				}
//			
//question 10 : for :
				
// question 14 : 				
				
	}
}


