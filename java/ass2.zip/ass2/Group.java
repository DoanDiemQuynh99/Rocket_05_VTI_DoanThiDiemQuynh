package Ass2;
import java.time.LocalDate;

public class Group {
	int groupID;
	String groupName;
	LocalDate createDate;
	 Account[] accounts;
}
