package Ass2;
import java.util.Scanner;
import java.time.LocalDate;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
public class exersise5 {

	public static void main(String[] args) throws ParseException {
	
	//Question 1: Viết lệnh cho phép người dùng nhập 3 số nguyên vào chương	trình
//		Scanner nhap = new Scanner (System.in);
//		//input
//		for(int i=1;i<=3 ;i++)
//		{
//		System.out.println("moi ban nhap vao:");
//		int soThuNhat = nhap.nextInt();
//		System.out.println("input"+soThuNhat);
//				}
	// Question 2: Viết lệnh cho phép người dùng nhập 2 số thực vào chương trình
//		Scanner nhap1 = new Scanner (System.in);
//		//input
//		for(int i=1;i<3 ;i++)
//		{
//		System.out.println("moi ban nhap vao:");
//		double soThuNhat = nhap1.nextDouble();
//		System.out.println("input"+soThuNhat);
//				}
	//Question 3: Viết lệnh cho phép người dùng nhập họ và tên
//		Scanner nhap2 = new Scanner (System.in);
//		//input
//		System.out.println("moi ban nhap vao ho ten:");
//		String ho_ten = nhap2.next();
//		System.out.println("input"+ho_ten);
	//Question 4: Viết lệnh cho phép người dùng nhập vào ngày sinh nhật của họ
//		Scanner nhap3 =new Scanner(System.in);
//		//input
//		System.out.println("moi ban nhap vao ngay sinh(MM-dd-yyyy):");
//		String dateInput = nhap3.next();
//		
//		String pt ="MM-dd-yyyy";
//		SimpleDateFormat dateFormat = new SimpleDateFormat(pt);
//		Date date = dateFormat.parse(dateInput);
//		System.out.println("input "+date);
		
	/*	Question 5: Viết lệnh cho phép người dùng tạo account (viết thành method)
		Đối với property Position, Người dùng nhập vào 1 2 3 4 5 và vào
		chương trình sẽ chuyển thành Position.Dev, Position.Test,
		Position.ScrumMaster, Position.PM*/
	
		
		
		
		
		
	/*Question 6: Viết lệnh cho phép người dùng tạo department (viết thành
method)*/
		
		
		
		
		
		
		
/*Question 7: Nhập số chẵn từ console*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

}
}
