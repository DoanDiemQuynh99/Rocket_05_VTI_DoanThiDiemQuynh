package Ass2;
public class Department {
	int departmentID;
	String departmentName;

}
