package Ass2;
import java.time.LocalDate;

public class Question {
	int questionID, categoryID, typeID, creatorID;
	String content;
	LocalDate createDate;
}
