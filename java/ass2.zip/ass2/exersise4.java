package Ass2;
import java.time.LocalDate;
import java.util.Random;
public class exersise4 {

	public static void main(String[] args) {
//	//Question 1: In ngẫu nhiên ra 1 số nguyên
//	
//		Random rd1 = new Random();   // khai báo 1 đối tượng Random
//	    int number = rd1.nextInt();  // trả về 1 số nguyên bất kỳ
//	    System.out.println("Số vừa được sinh ra là " + number);
//	        
//	  //Question 2:In ngẫu nhiên ra 1 số thực
//	    
//	    Random rd2 = new Random();   // khai báo 1 đối tượng Random
//	    double number1 = rd2.nextDouble();  // trả về 1 số nguyên bất kỳ
//	    System.out.println("Số vừa được sinh ra là " + number1);
//	    
//	  //question 3:Khai báo 1 array bao gồm các tên của các bạn trong lớp, sau đó in ngẫu nhiên ra tên của 1 bạn
//	    Random rd3= new Random();   // khai báo 1 đối tượng Random
//	    String[] ten = {"Quynh","Minh","Tung"};
//	    int i = rd3.nextInt(ten.length);
//	    System.out.println("in ra ten ban:"+ ten[1]);
//	    
//	  //question4: Lấy ngẫu nhiên 1 ngày trong khoảng thời gian 24-07-1995 tới ngày 20-12-1995
//	    Random rd4= new Random();
//	    int minDay= (int)LocalDate.of(1995, 7, 24).toEpochDay();
//	    int maxDay = (int)LocalDate.of(1995, 12, 20).toEpochDay();
//	     long randomInt = minDay+ rd4.nextInt(maxDay - minDay);
//	     LocalDate randomDay = LocalDate.ofEpochDay(randomInt);
//	     System.out.println(randomDay);
	    
	  // Question 5: Lấy ngẫu nhiên 1 ngày trong khoảng thời gian 1 năm trở lại đây  
//	    Random rd5 = new Random();
//	    int now = (int) LocalDate.now().toEpochDay();
//		long randomInt=now - rd5.nextInt(365);
//		LocalDate randomDay = LocalDate.ofEpochDay(randomInt);
//		System.out.println(randomDay);
//		
	//Question 6: Lấy ngẫu nhiên 1 ngày trong quá khứ
//		Random rd6 = new Random();
//		int now = (int) LocalDate.now().toEpochDay();
//		long randomInt=now - rd6.nextInt();
//		LocalDate randomDay = LocalDate.ofEpochDay(randomInt);
//		System.out.println(randomDay);
		
	//Question 7: Lấy ngẫu nhiên 1 số có 3 chữ số
		int  number;
	    Random rd7 = new Random();
	    Scanner scanner = new Scanner();
	    for (int i = 0; i < 1000 ; i++) {
	    number = 100 + rd7.nextInt(1000);
	    System.out.println("in ra"+ number);
	       
	    }
	  
			
		
			
		

	}


	    
	}


