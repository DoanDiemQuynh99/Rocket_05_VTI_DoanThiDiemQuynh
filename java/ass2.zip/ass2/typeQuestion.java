package Ass2;

public class typeQuestion {
	int typeID;
	String typeName;
}
