package ass3;

import java.time.LocalDate;
public class Account {
	static double luong;
	static int accountID, departmentID, positionID;
	static String email, userName, fullName;
	static LocalDate createDate;
	
	
	
}
