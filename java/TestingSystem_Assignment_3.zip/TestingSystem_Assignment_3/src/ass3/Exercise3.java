package ass3;

public class Exercise3 {

	public static void main(String[] args) {
		// Boxing & Unboxing
//question1:Khởi tạo lương có datatype là Integer có giá trị bằng 5000.
//		int luong5000;
//		Integer y =Integer.valueOf(luong);
//		float newFloat = (float)y;
//		System.out.println(newFloat);
//		String.format("%.2g%n", newFloat);
		
//question2:Khai báo 1 String có value = "1234567"
		//Hãy convert String đó ra số int
//		String y1= "1234567";
//		int i = Integer.parseInt(y1);
//		System.out.println(i);
//		
//question3:Khởi tạo 1 số Integer có value là chữ "1234567"
		//Sau đó convert số trên thành datatype int	
//		Integer i1 = Integer.valueOf("1234567");
//		String i2 = String.valueOf(i1);
//		System.out.println(i2);
		
		
		
	}

}
