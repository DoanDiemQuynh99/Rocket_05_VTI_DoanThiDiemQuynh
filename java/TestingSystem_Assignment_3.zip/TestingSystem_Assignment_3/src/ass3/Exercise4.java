
package ass3;
import java.util.Random;
import java.util.Scanner;
public class Exercise4 {

	public static void main(String[] args) {
		// String

//	question1();
//	question2();
	//question3();
	//question4();
	//question5();
	//question6();
	//question7();
	//question8();
	//	question9();
	//question10();
	question11();
	question12();
		
	}

private static void question12() {
//Đảo ngược chuỗi sử dụng vòng lặp
	
		Scanner scanner = new Scanner(System.in);
		String s1, reverseS1 = "";

		System.out.println("Nhập chuỗi 1");
		s1 = scanner.nextLine();

		for (int i = s1.length() - 1; i >= 0; i--) {
			reverseS1 += s1.charAt(i);
		}

		System.out.println(reverseS1);

		scanner.close();

	}

		
	

private static void question11() {
//Tìm số lần xuất hiện ký tự "a" trong chuỗi
	String str11 = "Quynh la con gai nha ";
	int count = 0;
	for (int i = 0; i < str11.length(); i++) {
		if ('a' == str11.charAt(i)) {
			count++;
		}
	}

	System.out.println(count);
}



//private static void question10() {
//question10:Kiểm tra 2 chuỗi có là đảo ngược của nhau hay không.
//	Nếu có xuất ra “OK” ngược lại “KO”.
//	Ví dụ “word” và “drow” là 2 chuỗi đảo ngược nhau.
//	Scanner scanner = new Scanner(System.in);
//	String str1,str2,reverseS1 = "";
//	System.out.println("nhap chuoi1");
//	str1= scanner.nextLine();
//	
//	System.out.println("nhap chuoi2");
//	str2 =scanner.nextLine();
//	
//	scanner.close();
//	
	
	
		
//	}

//private static void question2() {
//  q2:Nhập hai xâu kí tự s1, s2 nối xâu kí tự s2 vào sau xâu s1;
//	String s2;
//	Scanner scanner = new Scanner(System.in);
//	System.out.println("nhap chuoi");
//	s2 =scanner.nextLine();
//	
//	String s3;
//	Scanner scanner1 = new Scanner(System.in);
//	System.out.println("nhap chuoi");
//	s3 =scanner1.nextLine();
//	
//	System.out.println(s2+s3);
//	
//	
//	}
//
//question1:Nhập một xâu kí tự, đếm số lượng các từ trong xâu kí tự đó (các từ có
//thể cách nhau bằng nhiều khoảng trắng );
			
//	private static void question1() {
//		String s1;
//		Scanner scanner = new Scanner(System.in);
//		System.out.println("nhap chuoi");
//		s1 =scanner.nextLine();
//		String[] words = s1.split(" ");
//		System.out.println("Số kí tự: " + words.length);
//
//				
//	}
	
	
			//private static void question3()	{
//question3:Viết chương trình để người dùng nhập vào tên và kiểm tra, nếu tên chư
//viết hoa chữ cái đầu thì viết hoa lên
//		String s3 ;
//		Scanner canner3 = new Scanner(System.in);
//		System.out.println("Nhap chuoi");
//		s3 = canner3.nextLine();
//		String firstCharacter = s3.substring(0, 1).toUpperCase();
//
//		String leftCharacter = s3.substring(1);
//
//		s3 = firstCharacter + leftCharacter;
//
//		System.out.println(s3);
//		
//	}
	
	
//	private static void question4() {
//question4:Viết chương trình để người dùng nhập vào tên in từng ký tự trong tên
//của người dùng ra
//		String s4="NAM";  
//		System.out.println(s4.charAt(0)); 
//		System.out.println(s4.charAt(1)); 
//		System.out.println(s4.charAt(2)); 
//				
//	}
	
	
//	private static void question5() {
//Question5:Viết chương trình để người dùng nhập vào họ, sau đó yêu cầu người
//dùng nhập vào tên và hệ thống sẽ in ra họ và tên đầy đủ	
//	Scanner scanner5 = new Scanner(System.in);
//	String s5;
//	System.out.println("nhap ho");
//	s5 = scanner5.nextLine();
//	
//	String s6;
//	System.out.println("nhap ten");
//	s6 = scanner5.nextLine();
//	
//	System.out.println(s5+s6);	
//		
//	}
	
	//@SuppressWarnings("deprecation")
//	@SuppressWarnings({ "deprecation", "null" })
//	private static void question6() {
//question6:Viết chương trình yêu cầu người dùng nhập vào họ và tên đầy đủ và
	//sau đó hệ thống sẽ tách ra họ, tên , tên đệm
	//	VD:
	//	Người dùng nhập vào "Nguyễn Văn Nam"
	//	Hệ thống sẽ in ra
	//	"Họ là: Nguyễn"
	//	"Tên đệm là: Văn"
	//	"Tên là: Nam"
		// chua chay dc
//	String s7 = null;
//	char kyTu;
//	Scanner scanner7 = new Scanner(System.in);
//	System.out.println("nhap chuoi");
//	
//	int i;
//	for (i=0; i<100; i++) {
//		 kyTu = s7.charAt(i);
//		 
//		// kiem tra kyTu co phai dau cach k?
//		 if(Character.isSpace(kyTu)) {
//	            // Nếu ký tự đó là khoảng trắng thì xuống dòng
//	            System.out.println();
//	        } else {
//	            System.out.print(kyTu);
//	        }
//		 
//	}	 
//	
//  }	
//	
//	private static void question7() {
// Viết chương trình yêu cầu người dùng nhập vào họ và tên đầy đủ và
	//chuẩn hóa họ và tên của họ như sau:
//			a) Xóa dấu cách ở đầu và cuối và giữa của chuỗi người dùng nhập
//			vào
//			VD: Nếu người dùng nhập vào " nguyễn văn nam " thì sẽ
//			chuẩn hóa thành "nguyễn văn nam"
//			b) Viết hoa chữ cái mỗi từ của người dùng
//			VD: Nếu người dùng nhập vào " nguyễn văn nam " thì sẽ
//			chuẩn hóa thành "Nguyễn Văn Nam"		
//		Scanner scanner = new Scanner(System.in);
//		String fullName;
//
//		System.out.println("Nhập họ tên đầy đủ");
//		fullName = scanner.nextLine();
//
//		scanner.close();
//
//		// remove space characters
//		fullName = fullName.trim();
//		fullName = fullName.replaceAll("\\s+", " ");
//
//		String[] words = fullName.split(" ");
//		fullName = "";
//
//		for (String word : words) {
//			String firstCharacter = word.substring(0, 1).toUpperCase();
//			String leftCharacter = word.substring(1);
//			word = firstCharacter + leftCharacter;
//
//			fullName += word + " ";
//		}
//
//		System.out.println("Họ tên sau khi chuẩn hóa: " + fullName);
//	}
//	private static void question8() {
////question8:In ra tất cả các group có chứa chữ "Java"
//		String[] groupNames = { "Java cơ bản", "Cách qua mônjv", "Học Java Advance" };
//		for (String groupName : groupNames) {
//			if (groupName.contains("Java")) {
//				System.out.println(groupName);
//			}
//		}
//		
//	}
//	
	private static void question9() {
//question9: In ra tất cả các group "Java"
		String[] groupNames1 = {"C#","Java","Python"};
		for (String groupName : groupNames1) {
			if (groupName.equals("Java")) {
				System.out.println(groupName);
			}
		}
		
	}


	
	
}	
	
	
	


