package ass3;

import ass3.Department;

public class Exersise5 {

	public static void main(String[] args) {
// Object’s Method
		Department[] departments = new Department[3];
		
		
		Department dep1= new Department();
		dep1.departmentID=1;
		dep1.departmentName="marketing";
		
		Department dep2= new Department();
		dep1.departmentID=2;
		dep1.departmentName="sale";
		
		
		Department dep3= new Department();
		dep1.departmentID=3;
		dep1.departmentName="lap trinh";
		
//In ra thông tin của phòng ban thứ 1 (sử dụng toString())			
		departments[0]= dep1;
		question1(dep1);
	
		
	}

	private static void question1(Department department) {
		System.out.println(department);
		
	}

	
	
	
	
}
