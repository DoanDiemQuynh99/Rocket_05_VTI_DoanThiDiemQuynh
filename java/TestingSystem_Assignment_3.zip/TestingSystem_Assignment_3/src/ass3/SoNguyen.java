package ass3;

import java.util.Random;
import java.util.Scanner;
public class SoNguyen {
	
//	static void thuong() {
//		Random rd2 = new Random();
//		Scanner scanner = new Scanner(System.in);
//		// input
//			
//		System.out.println("nhap a");
//		int a = scanner.nextInt();
//		
//		
//	
//		System.out.println("nhap b");
//		int b = scanner.nextInt();
//		
//		// tinh thuong
//		float c =(float)(a/b);
//		System.out.println(c);
		
		
	}
	 

