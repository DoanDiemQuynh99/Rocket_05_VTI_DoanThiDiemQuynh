package ass3;

public class Department {
	int departmentID;
	String departmentName;
}
