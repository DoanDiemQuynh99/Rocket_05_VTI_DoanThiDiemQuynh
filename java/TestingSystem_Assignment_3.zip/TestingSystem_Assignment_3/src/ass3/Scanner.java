package ass3;

import java.io.InputStream;

public class Scanner {

	public Scanner(InputStream in) {
		// TODO Auto-generated constructor stub
	}

}
