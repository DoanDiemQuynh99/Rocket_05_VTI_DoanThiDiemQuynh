package ass3;

import java.util.Random;

import Ass2.Scanner;

public class Exersise1 {

	public static void main(String[] args) {
		//create account
		Account acc1 = new Account();
		acc1.accountID=1;
		acc1.departmentID=1;
		acc1.fullName= "Doan Thi Diem Quynh";
		acc1.luong = 5240.5;
		
		Account acc2 = new Account();
		acc2.accountID =2;
		acc2.departmentID=1;
		acc2.fullName ="Pham Duc Duy";
		acc2.luong =10970.055;
		
		
/*question1:Khai báo 2 số lương có kiểu dữ liệu là float.
		Khởi tạo Lương của Account 1 là 5240.5 $
		Khởi tạo Lương của Account 2 là 10970.055$
		Khai báo 1 số int để làm tròn Lương của Account 1 và in số int đó ra
		Khai báo 1 số int để làm tròn Lương của Account 2 và in số int đó ra*/
		
//		acc1.luong = 5240.5;
//		double luong1= Account.luong;
//		int soLuong1 = (int)luong1;
//		System.out.println("so luong cua nguoi 1:"+soLuong1);
//		
//		acc2.luong=10970.055;
//		double luong2= Account.luong;
//		int soLuong2= (int)luong2;
//		System.out.println("so luong cua nguoi 2:"+ soLuong2);
		
/*question2:Lấy ngẫu nhiên 1 số có 5 chữ số (những số dưới 5 chữ số thì sẽ thêm
có số 0 ở đầu cho đủ 5 chữ số)*/
//		int number;
//		Random rd1 = new Random(); 
//		Scanner scanner = new Scanner();
//	    number = 0 + rd1.nextInt(100000);	   
//	    if (number<10000) {
//	    	System.out.println("0"+number);
//	    }else {
//	    	System.out.println(number);
//	    }
/*question3:Lấy 2 số cuối của số ở Question 2 và in ra.
Gợi ý:
Cách 1: convert số có 5 chữ số ra String, sau đó lấy 2 số cuối
Cách 2: chia lấy dư số đó cho 100*/
//	    int a=100;int number;
//	    Random rd1 = new Random(); 
//	    Scanner scanner = new Scanner();
//	    number = 0 + rd1.nextInt(100000);
//	    float c = (float)(number/a);
//	    System.out.println(c);
//			
		
/*question 4:Viết 1 method nhập vào 2 số nguyên a và b và trả về thương của chúng*/	
//	SoNguyen.thuong();	
		
	
	}

}
