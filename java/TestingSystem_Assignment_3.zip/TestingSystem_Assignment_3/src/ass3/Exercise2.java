package ass3;

import java.time.LocalDate;

public class Exercise2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account[] accounts = new Account[5];
	//insert 
		for (int i = 0; i < 5; i++) {
			Account account = new Account();
			account.email = "Email " + (i);
			account.userName = "Username " + (i);
			account.fullName = "Full name " + (i);
			account.createDate = LocalDate.now();
			accounts[i] = account;
					}
		// print accounts
		for (Account account : accounts) {
			System.out.println(account.email);
			System.out.println(account.userName);
			System.out.println(account.fullName);
			System.out.println(account.createDate);
			System.out.println("\n");
			
		}
	}

}
