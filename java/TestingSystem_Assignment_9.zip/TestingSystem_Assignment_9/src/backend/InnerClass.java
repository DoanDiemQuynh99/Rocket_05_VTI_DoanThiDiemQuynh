package backend;

import entiny.CPU;
import entiny.CPU.Ram;
import entiny.Car;
import entiny.Car.Engine;

public class InnerClass {
private static final String Car = null;

//question1:
	public void question1() {
		
		CPU cpu = new CPU(10);
		CPU.Ram ram = cpu.Ram(4, "Dell");
		CPU.Processor processor = cpu.Processor(4, "Dell");
		
		System.out.println(cpu.getCache());
		System.out.println(cpu.getClockSpeed());
	}
	
//question2
	public void question2() {
		Car car = new Car("Mazda", 8);
		Engine engine = car.new Engine();
		engine.setEngineType("Crysler");

		car.setEngine(engine);

		System.out.println(car.setEngine(engine));

		
		
		
	}
}
