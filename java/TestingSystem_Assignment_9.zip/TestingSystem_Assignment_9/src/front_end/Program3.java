package front_end;

import backend.InnerClass;

public class Program3 {

	public static void main(String[] args) {
		InnerClass innerClass = new InnerClass();
		innerClass.question1();
		
		innerClass.question2();
	}

}
