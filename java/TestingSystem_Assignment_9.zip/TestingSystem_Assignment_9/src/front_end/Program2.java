package front_end;

import java.util.Date;

import backend.Exersise2;

public class Program2 {

	public static void main(String[] args) {
	
		question1();

	}
	@SuppressWarnings("deprecation")
	
		public static void question1(){
			Date date = new Date(2020, 4, 29);
			System.out.println(date);
		}
}
