package entiny;

public class Car {
private static final String car = null;
private String name;
private int type;
private String engineType;

public Car(String name, int type) {
	super();
	this.name = "Mazda";
	this.type = 8;
}

public Car() {
	
}

public class Engine {
	private String engineType;

	public Engine(String engineType){
		this.engineType=engineType;
	}

	public Engine() {
		// TODO Auto-generated constructor stub
	}

	public String getEngineType() {
		return engineType;
	}

	public void setEngineType(String engineType) {
		this.engineType = engineType;
	}
	
	
	
}

public String setEngine(Engine engine) {
	 ;
	// TODO Auto-generated method stub
	return name;
	
}


	
}





