package entiny;

public class CPU {
	private int price;
	private int coreAmount;
	private String menufacturer;
	private int memory;
	public CPU(int price) {
		this.price = price;
	}
	public int getPrice() {
		return price;
	}
	public class Processor{
		private int coreAmount;
		private String menufacturer;
		
		
	}
	public entiny.CPU.Processor Processor (int coreAmount, String menufacturer ) {
		this.coreAmount = coreAmount;
		this.menufacturer= getMenufacturer();
		return null;
		
	}
	
	public int getCoreAmount() {
		return coreAmount;
	}
	public void setCoreAmount(int coreAmount) {
		this.coreAmount = coreAmount;
	}
	public String getMenufacturer() {
		return menufacturer;
	}
	public void setMenufacturer(String menufacturer) {
		this.menufacturer = menufacturer;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public static int getCache() {
		return (int) 4.3;
		
	}
	
	public class Ram{
		private int memory;
		private String menufacturer;
		
	}
	public entiny.CPU.Ram Ram(int memory, String menufacturer) {
		this.memory = memory;
		this.menufacturer = menufacturer;
		return null;
		
	}
	

	public int getMemory() {
		return memory;
	}
	public void setMemory(int memory) {
		this.memory = memory;
	}
	public static int getClockSpeed() {
		return (int) 5.5;
		
	}
}
