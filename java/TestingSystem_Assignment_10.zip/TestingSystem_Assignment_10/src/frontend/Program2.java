package frontend;

import java.sql.SQLException;
import java.util.List;

import backend.DepartmentDao;
import backend.Excercise1;
import entity.Department;

public class Program2 {
	
	public static void main(String[] args) throws SQLException {
		Excercise1 ex1= new Excercise1();
	    ex1.getConnection();
	    
	    
		DepartmentDao departmentDao = new DepartmentDao();
		List<Department> departments = departmentDao.getDepartment();
		for(Department department:departments) {
			System.out.println(department.getDepartmentID()+department.getDepartmentName());
		}
	}

}
