package frontend;

import java.sql.Connection;
import java.sql.SQLException;

import backend.Excercise1;

public class Program1 {

	public static void main(String[] args) throws SQLException {
		Excercise1 ex1= new Excercise1();
	    ex1.getConnection();
	    ex1.question2();
	
	}

}
