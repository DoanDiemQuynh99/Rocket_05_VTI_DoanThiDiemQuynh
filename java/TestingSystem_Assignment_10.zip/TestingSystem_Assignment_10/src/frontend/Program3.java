package frontend;

public class Program3 {
	int x;
	public static void main(String[] args) {
		
	}

}
