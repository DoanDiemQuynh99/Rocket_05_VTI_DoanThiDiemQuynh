package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Excercise1 {
//get a connection to database
	String dbUrl = "jdbc:mysql://localhost:3306/testingsystem";
	String username = "root";
	String password = "root";
	public Connection getConnection() throws SQLException { 
	

	Connection myConnection = DriverManager.getConnection(dbUrl, username, password);
	System.out.println("Connect success");
	return myConnection;
	
	}
	public void question2() throws SQLException {
	Connection myConnection = DriverManager.getConnection(dbUrl, username, password);
	Statement statement = myConnection.createStatement();
	
	String query = "select * from position";
	ResultSet hung1 = statement.executeQuery(query);
	while (hung1.next()) {
		System.out.println(hung1.getInt(1)+""+hung1.getString(2));
	}
	
}
}	

