package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entity.Department;

public class DepartmentDao {
	private DepartmentDao dao;
	public List<Department> getDepartment() {
		List<Department> departments = new ArrayList<>(); 
		
		return null;
	}
	
	public Department getDepartmentById(Department id) throws Exception {
		//get a connection to database
		String dbUrl = "jdbc:mysql://localhost:3306/testingsystem";
		String username = "root";
		String password = "root";
		
		Connection myConnection = DriverManager.getConnection(dbUrl, username, password);
		Statement statement = myConnection.createStatement();
		
		String query1 = "select * from Department where DepartmentId=?";
		ResultSet hung1 = statement.executeQuery(query1);
		PreparedStatement ps = myConnection.prepareStatement(query1);
		ps.setInt(1,21);
		
		return id;
		
		
		
		}
	}
	
	
	


