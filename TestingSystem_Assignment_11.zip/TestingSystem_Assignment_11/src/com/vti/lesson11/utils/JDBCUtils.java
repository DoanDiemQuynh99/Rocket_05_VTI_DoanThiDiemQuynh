package com.vti.lesson11.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCUtils {

	private Connection con;

	public Connection getConnection() throws SQLException {
		if (con == null || con.isClosed()) {
			String dbUrl = "jdbc:mysql://localhost:3306/testingsystem";
			String username = "root";
			String password = "root";
			con = DriverManager.getConnection(dbUrl, username, password);

		}
		return con;
	}
	public void disconnect() throws SQLException {
		if(con != null && !con.isClosed()) {
			con.close();
		}
	}

}
