package com.vti.lesson11.frontend;

import java.sql.SQLException;
import java.util.List;

import com.vti.lesson11.backend.presentationlayer.AccountController;
import com.vti.lesson11.entity.Account;

public class Program {

	public static void main(String[] args) throws SQLException {
		AccountController accountController = new AccountController();
		List<Account> accountList = accountController.getListAccount();
		for (Account account : accountList) {
			System.out.println(account.getUsername()+account.getEmail());
		}
		accountController.updateEmailByUsername("1dangblackkk", "DANGEgmail.com");
		//dangblack
	}

}
