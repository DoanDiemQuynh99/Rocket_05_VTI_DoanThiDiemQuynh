package com.vti.lesson11.backend.datalayer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.vti.lesson11.entity.Account;
import com.vti.lesson11.utils.JDBCUtils;

public class AccountRepository {
	private JDBCUtils jdbcutils;

	public AccountRepository() {
		jdbcutils = new JDBCUtils();
	}
	

	public List<Account> getListAccounts() throws SQLException {
		List<Account> accounts = new ArrayList<>();
		Connection myConnect = jdbcutils.getConnection();
		String query1 = "Select Username, Email From `Account`";
		Statement statement = myConnect.createStatement();
		ResultSet resultset = statement.executeQuery(query1);
		
		while (resultset.next()) {
			Account account;
			String Username=resultset.getString("Username");
			String Email=resultset.getString("Email");
			account = new Account(Username, Email);
			accounts.add(account);
		}
		myConnect.close();
		return accounts;

	}


	public void updateEmailByUsername(String username) {
		
	}

}
