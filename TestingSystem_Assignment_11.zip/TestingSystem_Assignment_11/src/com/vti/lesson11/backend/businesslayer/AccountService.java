package com.vti.lesson11.backend.businesslayer;

import java.sql.SQLException;
import java.util.List;

import com.vti.lesson11.backend.datalayer.AccountRepository;
import com.vti.lesson11.entity.Account;

public class AccountService {
	
	private AccountRepository accountRepository;
	public AccountService() {
		accountRepository = new AccountRepository();
	}
	public List<Account> getListAccounts() throws SQLException {
		return accountRepository.getListAccounts();
	}
	public void updateEmailByUsername(String Username, String Email) {
		
//		if (username.charAt(0)là chữ)
//			accountRepository.updateEmailByUsername(Username, Email);
//		else {
//			// dữ liệu ko hợp lệ 
//		}
	}
}
